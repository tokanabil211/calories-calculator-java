import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CalorieCalculator {
    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        int n;
        while (true) {
            try {
                System.out.print("Enter the number of persons: ");
                n = scanner.nextInt();
                scanner.nextLine(); // Consume the newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number of persons.");
                scanner.nextLine(); // Consume the invalid input
            }
        }

        String name;
        int age;
        double weight;
        double height;
        double maxBmi = Double.MIN_VALUE;
        String maxBmiName = "";
        double maxBmiValue = 0.0;
        double totalBmrM = 0.0;
        int numOptimalWeightM = 0;
        double totalBmrF = 0.0;
        int numOptimalWeightF = 0;
        double avgBmrM=0;
        double avgBmrF=0;
        int maxBmiage=0;
        double maxBmiweight=0.0;
        double maxBmiheight=0.0;
        String maxgender = "";




        try (
                FileWriter writer = new FileWriter("data.txt",true)) {
            PrintWriter input = new PrintWriter(writer);
            input.println("Name\tAge\tWeight\tHeight\tGender   \tBMR\t   BMI\tStatus\n");
            for (int i = 0; i < n; i++) {
                System.out.printf("Enter data for person "+i+"\n");
                System.out.print("Name: ");
                name = scanner.next();

                while (true) {
                    try {
                        System.out.print("Age (in years): ");
                        age = scanner.nextInt();
                        scanner.nextLine();
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid age.");
                        scanner.nextLine();
                    }
                }

                while (true) {
                    try {
                        System.out.print("Weight (in kilograms): ");
                        weight = scanner.nextDouble();
                        scanner.nextLine(); // consume the newline
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid weight.");
                        scanner.nextLine(); // consume the invalid input
                    }
                }

                while (true) {
                    try {
                        System.out.print("Height (in centimeters): ");
                        height = scanner.nextDouble();

                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid height.");
                        scanner.nextLine(); // consume the invalid input
                    }
                }

                scanner.nextLine(); // consume the newline
                System.out.print("Gender (M/F): ");
                String gender = scanner.nextLine();

                // calculate BMR and BMI
                double bmr, bmi;
                if (gender.equals("M")) {
                    bmr = 66 + 13.7 * weight + 5 * height - 6.8 * age;

                } else {
                    bmr = 655 + 9.6 * weight + 1.8 * height - 4.7 * age;
                }
                bmi = weight / Math.pow(height/100,2) ;
                // determine the weight status
                String status;
                if (bmi < 18.5) {
                    status = "Underweight";
                } else if (bmi < 25) {
                    status = "Optimal weight";
                    if (gender.equals("M")) {
                        totalBmrM+=bmr;
                        numOptimalWeightM++;

                    }else{
                        totalBmrF+=bmr;
                        numOptimalWeightF++;
                    }
                } else {
                    status = "Overweight";
                }
                if (bmi > maxBmi) {
                    maxBmi = bmi;
                    maxBmiName = name;
                    maxBmiValue = bmi;
                    maxBmiage=age;
                    maxBmiweight=weight;
                    maxBmiheight=height;
                    maxgender=gender;

                }


                // write the data to the file
                input.println(String.format("%s\t%d\t%.2f\t\t%.2f\t\t%s    \t%.2f\t%.2f\t%s\n\n",
                        name, age, weight, height, gender, bmr, bmi, status));

            }
            try{
                FileOutputStream fileOutputStream = new FileOutputStream("report.dat");
                PrintWriter report = new PrintWriter(fileOutputStream);
                report.printf("Details of persons with highest BMI values:\n");
                report.printf("The Name : %s\t\n The Bmi : %.2f\t\n The Age: %d\t\n The weight: %.2f\t\n The height:%.2f \t\n The gender: %s \t\n", maxBmiName, maxBmiValue,maxBmiage,maxBmiweight,maxBmiheight,maxgender);
                if (numOptimalWeightM > 0) {
                    avgBmrM = totalBmrM / numOptimalWeightM;
                    report.printf("\nAverage BMR value for optimal weight males: \n", avgBmrM);
                }
                if (numOptimalWeightF > 0) {
                    avgBmrF = totalBmrF / numOptimalWeightF;
                    report.printf("\nAverage BMR value for optimal weight females: %.2f\n", avgBmrF);
                }
                if(numOptimalWeightM == 0){
                    report.printf("\nAverage BMR value for optimal weight males: \n"+ avgBmrM);
                }
                if(numOptimalWeightF == 0){
                    report.printf("\nAverage BMR value for optimal weight females: \n"+ avgBmrF);
                }
                System.out.println("Details of persons with highest BMI values:\n");
                System.out.printf("The Name : %s\t\n The Bmi : %.2f\t\n The Age: %d\t\n The weight: %.2f\t\n The height:%.2f \t\n The gender: %s \t\n", maxBmiName, maxBmiValue,maxBmiage,maxBmiweight,maxBmiheight,maxgender);
                System.out.println("Average BMR value for optimal weight males: "+avgBmrM);
                System.out.println("Average BMR value for optimal weight females: "+avgBmrF);

                report.close();
                fileOutputStream.close();}
            catch (IOException e){
                System.err.println("Error: " + e.getMessage());
            }
            System.out.println("Data saved to persons.txt");
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}